@echo off
setlocal
title Restablecer contrasena - Sistema Medico Portable
cd /d "%~dp0"

echo ---------------------------------------------------
echo   RESTABLECER CONTRASENA DEL USUARIO admin
echo ---------------------------------------------------
echo La contrasena de "admin" volvera a ser la inicial (1234).
echo Las citas NO se modifican.
echo.
choice /c SN /m "Continuar"
if errorlevel 2 goto :fin

"%~dp0php\php.exe" -c "%~dp0php\php.ini" -d extension_dir="%~dp0php\ext" "%~dp0app\restablecer_clave.php"

:fin
echo.
pause
