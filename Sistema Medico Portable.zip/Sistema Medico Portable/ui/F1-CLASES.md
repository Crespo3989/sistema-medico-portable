# Estilos F1 para los componentes actuales

La capa `ui/f1.css` ya está importada por `ui/app.css` y compilada en `public/css/app.css`. No se cambian plantillas PHP, JavaScript de la aplicación ni datos. Los selectores actuales reciben los nuevos estilos automáticamente.

Referencia revisada: https://www.formula1.com/ el 21 de octubre de 2026. Se trasladan la navegación oscura, el rojo, los títulos de peso alto, las tablas de lectura densa y los remates redondeados asimétricos al sistema existente. Se conserva su contenido médico.

## Clases reutilizables

| Componente | Clases daisyUI / Tailwind |
| --- | --- |
| Acción principal | `btn btn-primary uppercase tracking-wide font-bold rounded-sm` |
| Acción secundaria | `btn btn-ghost uppercase tracking-wide font-bold rounded-sm` |
| Panel | `card bg-base-100 border-t-2 border-r-2 border-base-300 rounded-none rounded-tr-2xl` |
| Título | `text-base-content text-3xl md:text-5xl font-black uppercase tracking-tight leading-tight` |
| Descripción | `text-base-content/80 text-base leading-relaxed` |
| Campo | `input w-full rounded-sm` |
| Selector | `select w-full rounded-sm` |
| Estado | `badge rounded-sm font-semibold` |
| Tabla | `table w-full` |
| Grupo de acciones | `flex flex-wrap gap-2 md:gap-3` |
| Contenido y formulario | `grid grid-cols-1 gap-7 xl:grid-cols-[minmax(0,1fr)_21rem]` |

Las clases anteriores funcionan con el tema semántico configurado. Para los componentes que ya existen no es necesario añadirlas de nuevo: la capa CSS adapta `.tarjeta`, `.boton`, `.filtros`, `.resumen` y el resto de los selectores actuales.

## Tipografía

Titillium Web se incluye localmente en pesos 400, 600 y 700, con su licencia OFL en `public/fonts/`. El sitio oficial usa Formula1 para los títulos. Este proyecto no incluye esa fuente: `--racing-display` está preparado para usarla si se registra con `@font-face` bajo el nombre `Formula1`; mientras tanto utiliza Titillium Web. Por esta diferencia y por conservar la estructura de la app, el resultado es una adaptación visual, no una reproducción exacta de la web oficial.

## Compilación

Ejecuta `npm run build:css` después de cambiar los estilos. El CSS distribuido y las fuentes son locales; la app sigue funcionando sin Internet. Se conservan los modos claro, oscuro y sistema.

Para retirar esta capa basta con quitar la importación `@import "./f1.css" layer(racing);` de `ui/app.css` y recompilar.
