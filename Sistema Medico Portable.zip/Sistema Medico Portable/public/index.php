<?php
// Punto de entrada único: procesa los formularios (POST) y muestra la vista que corresponda (GET).
declare(strict_types=1);

$config = require __DIR__ . '/../app/config.php';
require __DIR__ . '/../app/seguridad.php';
require __DIR__ . '/../app/db.php';
require __DIR__ . '/../app/citas.php';
require __DIR__ . '/../app/formato.php';

date_default_timezone_set($config['zona_horaria']);
enviar_cabeceras_seguridad();
iniciar_sesion($config['minutos_inactividad']);

// Renueva el token del acceso sin reenviar credenciales ni ejecutar acciones.
if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['accion'] ?? '') === 'csrf') {
    header('Content-Type: application/json; charset=UTF-8');
    if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'SistemaMedico') {
        http_response_code(403);
        echo json_encode(['error' => 'Solicitud no válida.']);
        exit;
    }
    echo json_encode(['csrf' => token_csrf()]);
    exit;
}

try {
    $pdo = conectar($config['ruta_db']);
} catch (PDOException $e) {
    http_response_code(500);
    $titulo = 'Error';
    $usuario = null;
    $mensajes = [['error', 'No se pudo abrir la base de datos: ' . $e->getMessage()]];
    $vista = 'error';
    require __DIR__ . '/../app/vistas/layout.php';
    exit;
}

// Tras cada acción se redirige (patrón POST/Redirect/GET): recargar la página no repite el envío.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = (string) ($_POST['accion'] ?? '');
    if (!verificar_csrf()) {
        if ($accion === 'login') {
            $_SESSION['ultimo_usuario'] = trim((string) ($_POST['usuario'] ?? ''));
        }
        flash('info', isset($_SESSION['usuario_id'])
            ? 'Actualizamos el formulario por seguridad. Revisa los datos y vuelve a intentarlo.'
            : 'La sesión se actualizó. Ingresa nuevamente para continuar.');
        redirigir();
    }

    if ($accion === 'login') {
        $nombre = trim((string) ($_POST['usuario'] ?? ''));
        $clave = (string) ($_POST['clave'] ?? '');
        $stmt = $pdo->prepare('SELECT id, usuario, password FROM usuarios WHERE usuario = ?');
        $stmt->execute([$nombre]);
        $fila = $stmt->fetch();
        if ($fila && password_verify($clave, $fila['password'])) {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = (int) $fila['id'];
            $_SESSION['usuario'] = $fila['usuario'];
            $_SESSION['clave_inicial'] = $clave === CLAVE_INICIAL;
            if (password_needs_rehash($fila['password'], PASSWORD_DEFAULT)) {
                $pdo->prepare('UPDATE usuarios SET password = ? WHERE id = ?')
                    ->execute([password_hash($clave, PASSWORD_DEFAULT), $fila['id']]);
            }
            redirigir();
        }
        usleep(700000); // frena los intentos repetidos de adivinar contraseñas
        $_SESSION['ultimo_usuario'] = $nombre;
        flash('error', 'Usuario o contraseña incorrectos.');
        redirigir();
    }

    if ($accion === 'logout') {
        cerrar_sesion();
        flash('info', 'Sesión cerrada.');
        redirigir();
    }

    // Todas las acciones siguientes requieren haber iniciado sesión.
    if (!isset($_SESSION['usuario_id'])) {
        flash('error', 'Inicia sesión para continuar.');
        redirigir();
    }

    if ($accion === 'confirmar_eliminacion' || $accion === 'eliminar') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        $filtros = array_filter(leer_filtros($_GET, $config['especialidades']));
        $volver = 'index.php' . ($filtros ? '?' . http_build_query($filtros) : '');
        if ($accion === 'eliminar') {
            if (($_POST['confirmar'] ?? '') !== '1') {
                flash('error', 'Confirma la eliminación de la cita antes de continuar.');
                redirigir($volver);
            }
            $error = eliminar_cita($pdo, $id ?: 0);
            flash($error ? 'error' : 'exito', $error ?? 'Cita eliminada definitivamente.');
            redirigir($volver);
        }
        $stmt = $pdo->prepare('SELECT * FROM citas WHERE id = ?');
        $stmt->execute([$id ?: 0]);
        $cita_eliminar = $stmt->fetch();
        if (!$cita_eliminar) {
            flash('error', 'La cita no existe o ya fue eliminada.');
            redirigir($volver);
        }
        $usuario = $_SESSION['usuario'];
        $mensajes = tomar_flash();
        $vista = 'eliminar';
        $titulo = 'Eliminar cita';
        require __DIR__ . '/../app/vistas/layout.php';
        exit;
    }

    if ($accion === 'agendar') {
        [$datos, $errores] = validar_cita($_POST, $config['especialidades']);
        if (!$errores && horario_ocupado($pdo, $datos['especialidad'], $datos['fecha'], $datos['hora'])) {
            $errores['hora'] = 'Ya hay una cita de ' . $datos['especialidad'] . ' en ese horario.';
        }
        if ($errores) {
            $_SESSION['form_cita'] = ['datos' => $datos, 'errores' => $errores];
            flash('error', 'Revisa los datos de la cita.');
        } else {
            crear_cita($pdo, $datos);
            flash('exito', 'Cita de ' . $datos['paciente'] . ' registrada.');
        }
        redirigir();
    }

    if ($accion === 'estado') {
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $error = $id ? cambiar_estado($pdo, $id, (string) ($_POST['estado'] ?? '')) : 'La cita no existe.';
        flash($error ? 'error' : 'exito', $error ?? 'Estado de la cita actualizado.');
        $filtros = array_filter(leer_filtros($_GET, $config['especialidades']));
        redirigir('index.php' . ($filtros ? '?' . http_build_query($filtros) : ''));
    }

    if ($accion === 'clave') {
        $actual = (string) ($_POST['actual'] ?? '');
        $nueva = (string) ($_POST['nueva'] ?? '');
        $stmt = $pdo->prepare('SELECT password FROM usuarios WHERE id = ?');
        $stmt->execute([$_SESSION['usuario_id']]);
        $hash = (string) $stmt->fetchColumn();
        $error = match (true) {
            !password_verify($actual, $hash)            => 'La contraseña actual no es correcta.',
            strlen($nueva) < 8                          => 'La nueva contraseña debe tener al menos 8 caracteres.',
            $nueva !== ($_POST['confirmar'] ?? null)    => 'Las contraseñas nuevas no coinciden.',
            $nueva === $actual                          => 'La nueva contraseña debe ser distinta de la actual.',
            default                                     => null,
        };
        if ($error) {
            flash('error', $error);
            redirigir('index.php?vista=clave');
        }
        $pdo->prepare('UPDATE usuarios SET password = ? WHERE id = ?')
            ->execute([password_hash($nueva, PASSWORD_DEFAULT), $_SESSION['usuario_id']]);
        session_regenerate_id(true);
        $_SESSION['clave_inicial'] = false;
        flash('exito', 'Contraseña actualizada.');
        redirigir();
    }

    redirigir();
}

$usuario = $_SESSION['usuario'] ?? null;
$mensajes = tomar_flash();

if ($usuario === null) {
    $vista = 'login';
    $titulo = 'Acceso';
    $mostrar_pista = clave_inicial_activa($pdo);
    $ultimo_usuario = $_SESSION['ultimo_usuario'] ?? '';
    unset($_SESSION['ultimo_usuario']);
} elseif (($_GET['vista'] ?? '') === 'clave') {
    $vista = 'clave';
    $titulo = 'Cambiar contraseña';
} else {
    $vista = 'panel';
    $titulo = 'Citas';
    $hoy = date('Y-m-d');
    $filtros = leer_filtros($_GET, $config['especialidades']);
    $citas = listar_citas($pdo, $filtros);
    $resumen = resumen_citas($pdo, $hoy);
    $form = $_SESSION['form_cita'] ?? ['datos' => [], 'errores' => []];
    unset($_SESSION['form_cita']);
}

require __DIR__ . '/../app/vistas/layout.php';
