// Óptica local: solo se renderiza un fondo decorativo, nunca el DOM clínico.
const preferencias = [
    matchMedia('(prefers-reduced-motion: reduce)'),
    matchMedia('(prefers-reduced-transparency: reduce)'),
    matchMedia('(prefers-contrast: more)'),
];
const tema = matchMedia('(prefers-color-scheme: dark)');
let instancia = null;
let escena = null;
let fondo = null;
let lentes = [];
let revision = 0;
let pendiente = 0;
let observador = null;

function permitido() {
    return !document.hidden && !preferencias.some((preferencia) => preferencia.matches);
}

function pintarFondo() {
    const escala = Math.min(devicePixelRatio || 1, 1.5);
    fondo.width = Math.round(innerWidth * escala);
    fondo.height = Math.round(innerHeight * escala);
    const contexto = fondo.getContext('2d');
    contexto.scale(escala, escala);
    contexto.fillStyle = tema.matches ? '#0e1826' : '#edf4fc';
    contexto.fillRect(0, 0, innerWidth, innerHeight);
    const manchas = tema.matches
        ? [[.08, .08, '#193655'], [.98, .7, '#17344c']]
        : [[.08, .08, '#dceafa'], [.98, .7, '#d8ecf6']];
    for (const [x, y, color] of manchas) {
        const radio = Math.max(innerWidth, innerHeight) * .62;
        const gradiente = contexto.createRadialGradient(innerWidth * x, innerHeight * y, 0, innerWidth * x, innerHeight * y, radio);
        gradiente.addColorStop(0, color);
        gradiente.addColorStop(1, `${color}00`);
        contexto.fillStyle = gradiente;
        contexto.fillRect(0, 0, innerWidth, innerHeight);
    }
}

function colocarLentes() {
    for (const { elemento, superficie } of lentes) {
        const rect = superficie.getBoundingClientRect();
        elemento.hidden = rect.width === 0 || rect.height === 0;
        Object.assign(elemento.style, {
            left: `${rect.left}px`, top: `${rect.top}px`,
            width: `${rect.width}px`, height: `${rect.height}px`,
        });
    }
    instancia?.markChanged();
}

function actualizar() {
    if (!escena || pendiente) return;
    pendiente = requestAnimationFrame(() => {
        pendiente = 0;
        if (!escena) return;
        colocarLentes();
    });
}

function destruir() {
    revision++;
    cancelAnimationFrame(pendiente);
    pendiente = 0;
    observador?.disconnect();
    observador = null;
    instancia?.destroy();
    instancia = null;
    escena?.remove();
    escena = fondo = null;
    lentes = [];
    document.body.classList.remove('cristal-activo');
}

async function iniciar() {
    destruir();
    if (!permitido() || !window.WebGLRenderingContext || !document.body.classList.contains('vista-login')) return;
    const actual = revision;
    try {
        const { LiquidGlass } = await import('../vendor/liquidglass/index.js');
        if (actual !== revision || !permitido()) return;
        escena = document.createElement('div');
        escena.className = 'escena-cristal';
        escena.setAttribute('aria-hidden', 'true');
        fondo = document.createElement('canvas');
        fondo.className = 'fondo-cristal';
        escena.append(fondo);
        document.body.prepend(escena);
        pintarFondo();
        for (const superficie of document.querySelectorAll('.vista-login .acceso-tarjeta')) {
            const elemento = document.createElement('div');
            elemento.className = 'lente-cristal';
            elemento.dataset.config = JSON.stringify({
                cornerRadius: parseFloat(getComputedStyle(superficie).borderRadius) || 20,
                zRadius: 12,
                blurAmount: .2, refraction: .38,
                chromAberration: .015,
                edgeHighlight: .18, specular: .1,
                saturation: 0,
                fresnel: .7, shadowOpacity: .09, shadowSpread: 16,
                shadowOffsetY: 5, brightness: tema.matches ? .015 : .035,
                floating: false, button: false,
            });
            lentes.push({ elemento, superficie });
            escena.append(elemento);
        }
        colocarLentes();
        const nueva = await LiquidGlass.init({ root: escena, glassElements: lentes.map(({ elemento }) => elemento) });
        if (actual !== revision || !permitido()) {
            nueva.destroy();
            return;
        }
        instancia = nueva;
        document.body.classList.add('cristal-activo');
        observador = new ResizeObserver(actualizar);
        lentes.forEach(({ superficie }) => observador.observe(superficie));
    } catch {
        // La versión CSS permanece disponible si el equipo no admite WebGL.
        if (actual === revision) destruir();
    }
}

window.addEventListener('scroll', actualizar, { passive: true });
window.addEventListener('resize', () => {
    if (fondo) pintarFondo();
    actualizar();
}, { passive: true });
preferencias.forEach((preferencia) => preferencia.addEventListener('change', iniciar));
tema.addEventListener('change', iniciar);
document.addEventListener('visibilitychange', () => document.hidden ? destruir() : iniciar());
window.addEventListener('pagehide', destruir);
window.addEventListener('pageshow', (evento) => { if (evento.persisted) iniciar(); });
iniciar();
