// Mejoras progresivas: los formularios y la navegación funcionan sin JavaScript.
const reducirMovimiento = window.matchMedia('(prefers-reduced-motion: reduce)');
const desaceleracion = 'cubic-bezier(.16, 1, .3, 1)';
const animaciones = new Set();

function animar(elemento, fotogramas, duracion = 220) {
    if (!elemento?.animate) return null;
    const pasos = reducirMovimiento.matches
        ? fotogramas.map(({ opacity }) => ({ opacity: opacity ?? 1 }))
        : fotogramas;
    const animacion = elemento.animate(pasos, {
        duration: reducirMovimiento.matches ? 80 : duracion,
        easing: desaceleracion,
    });
    animaciones.add(animacion);
    animacion.finished.then(() => animaciones.delete(animacion), () => animaciones.delete(animacion));
    return animacion;
}

document.getElementById('imprimir')?.addEventListener('click', () => window.print());

// Una pestaña de acceso antigua obtiene un token vigente antes de enviar la clave.
// El servidor sigue comprobando CSRF en todos los POST; no se reintenta ninguna acción.
const acceso = document.querySelector('.vista-login .formulario');
if (acceso) {
    let renovando = false;
    let vigente = false;
    const usuario = acceso.querySelector('[name="usuario"]');
    usuario?.addEventListener('input', () => usuario.setCustomValidity(''));
    acceso.addEventListener('submit', async (evento) => {
        if (vigente) return;
        evento.preventDefault();
        if (renovando) return;
        renovando = true;
        acceso.setAttribute('aria-busy', 'true');
        const boton = evento.submitter || acceso.querySelector('button[type="submit"]');
        try {
            const respuesta = await fetch('index.php?accion=csrf', {
                credentials: 'same-origin', cache: 'no-store',
                headers: { 'X-Requested-With': 'SistemaMedico' },
            });
            if (!respuesta.ok) throw new Error('Sesión no disponible');
            const datos = await respuesta.json();
            if (typeof datos.csrf !== 'string' || !/^[a-f0-9]{64}$/.test(datos.csrf)) {
                throw new Error('Token no válido');
            }
            acceso.querySelector('[name="csrf"]').value = datos.csrf;
            usuario?.setCustomValidity('');
            vigente = true;
            acceso.requestSubmit(boton);
            vigente = false;
        } catch {
            usuario?.setCustomValidity('No se pudo conectar con el sistema. Comprueba que esté abierto y vuelve a intentarlo.');
            usuario?.reportValidity();
            // Permite volver a pulsar Ingresar sin modificar lo que ya se escribió.
            usuario?.setCustomValidity('');
        } finally {
            renovando = false;
            acceso.removeAttribute('aria-busy');
        }
    });
}

// El menú nace desde su botón. Al invertirlo, parte de su posición visible actual.
const menu = document.querySelector('.menu-usuario');
if (menu) {
    const disparador = menu.querySelector('summary');
    const contenido = menu.querySelector('.menu-desplegable');
    let transicion = null;
    let abierto = menu.open;
    const cambiarMenu = (abrir) => {
        abierto = abrir;
        if (abrir && !menu.open) {
            menu.open = true;
            contenido.inert = false;
            transicion = animar(contenido, [
                { opacity: 0, transform: 'translateY(-6px) scale(.97)' },
                { opacity: 1, transform: 'translateY(0) scale(1)' },
            ]);
            return;
        }
        const actual = getComputedStyle(contenido);
        const inicio = { opacity: actual.opacity, transform: actual.transform };
        transicion?.cancel();
        contenido.inert = !abrir;
        if (!abrir && contenido.contains(document.activeElement)) disparador.focus();
        transicion = animar(contenido, [inicio, {
            opacity: abrir ? 1 : 0,
            transform: abrir ? 'translateY(0) scale(1)' : 'translateY(-6px) scale(.97)',
        }], abrir ? 220 : 140);
        if (!transicion) {
            menu.open = abrir;
            return;
        }
        transicion.finished.then(() => { if (!abierto) menu.open = false; }, () => {});
    };
    disparador.addEventListener('click', (evento) => {
        evento.preventDefault();
        cambiarMenu(!abierto);
    });
    document.addEventListener('click', (evento) => {
        if (abierto && !menu.contains(evento.target)) cambiarMenu(false);
    });
    document.addEventListener('keydown', (evento) => {
        if (evento.key === 'Escape' && abierto) {
            cambiarMenu(false);
            disparador.focus();
        }
    });
}

// Respuesta física de presión: resorte críticamente amortiguado, sin rebotes.
// La posición y velocidad se conservan al interrumpir o invertir la pulsación.
const resortes = new Set();
document.querySelectorAll('.boton').forEach((boton) => {
    boton.dataset.resorte = '';
    let escala = 1;
    let velocidad = 0;
    let destino = 1;
    let frame = 0;
    let anterior = 0;
    const restablecer = () => {
        cancelAnimationFrame(frame);
        frame = 0;
        escala = destino = 1;
        velocidad = 0;
        boton.style.removeProperty('--presion');
    };
    resortes.add(restablecer);
    const avanzar = (tiempo) => {
        const dt = Math.min((tiempo - anterior) / 1000, .025);
        anterior = tiempo;
        const aceleracion = 500 * (destino - escala) - 45 * velocidad;
        velocidad += aceleracion * dt;
        escala += velocidad * dt;
        boton.style.setProperty('--presion', escala.toFixed(5));
        if (Math.abs(destino - escala) < .0001 && Math.abs(velocidad) < .001) {
            frame = 0;
            boton.style.setProperty('--presion', String(destino));
            return;
        }
        frame = requestAnimationFrame(avanzar);
    };
    const presionar = (activo) => {
        if (reducirMovimiento.matches || boton.disabled) return;
        destino = activo ? .975 : 1;
        if (!frame) {
            anterior = performance.now();
            frame = requestAnimationFrame(avanzar);
        }
    };
    boton.addEventListener('pointerdown', (evento) => {
        if (evento.button === 0) presionar(true);
    });
    ['pointerup', 'pointerleave', 'pointercancel', 'blur'].forEach((evento) => {
        boton.addEventListener(evento, () => presionar(false));
    });
    boton.addEventListener('keydown', (evento) => {
        if (evento.key === ' ' || evento.key === 'Enter') presionar(true);
    });
    boton.addEventListener('keyup', () => presionar(false));
});

// Los mensajes permanecen disponibles hasta que el usuario decide cerrarlos.
document.querySelectorAll('.aviso').forEach((aviso) => {
    if (!aviso.matches('.aviso-alerta')) {
        animar(aviso, [{ opacity: .3, transform: 'translateY(-5px)' }, { opacity: 1, transform: 'translateY(0)' }]);
    }
    if (!aviso.matches('.aviso-exito, .aviso-info')) return;
    const cerrar = document.createElement('button');
    cerrar.type = 'button';
    cerrar.className = 'cerrar-aviso';
    cerrar.setAttribute('aria-label', 'Cerrar aviso');
    cerrar.innerHTML = '<svg class="icono" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>';
    cerrar.addEventListener('click', () => {
        cerrar.disabled = true;
        const salida = animar(aviso, [{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: 'translateY(-5px)' }], 140);
        const retirar = () => {
            if (aviso.contains(document.activeElement)) {
                (document.querySelector('input:not([type=hidden])') || document.getElementById('contenido'))?.focus({ preventScroll: true });
            }
            aviso.remove();
        };
        if (salida) salida.finished.then(retirar, retirar);
        else retirar();
    });
    aviso.append(cerrar);
});

document.querySelectorAll('[data-clave]').forEach((boton) => {
    boton.addEventListener('click', () => {
        const campo = document.getElementById(boton.dataset.clave);
        if (!campo) return;
        const visible = campo.type === 'password';
        campo.type = visible ? 'text' : 'password';
        boton.setAttribute('aria-pressed', String(visible));
        boton.setAttribute('aria-label', visible ? 'Ocultar contraseña' : 'Mostrar contraseña');
    });
});

// Orientación hacia la tarea: desplazamiento nativo interrumpible y foco inmediato.
let atencionFormulario = null;
document.querySelectorAll('a[href="#nueva-cita"]').forEach((enlace) => {
    enlace.addEventListener('click', (evento) => {
        const campo = document.getElementById('paciente');
        const formulario = document.getElementById('nueva-cita');
        if (!campo || !formulario) return;
        evento.preventDefault();
        campo.focus({ preventScroll: true });
        formulario.scrollIntoView({ block: 'start', behavior: reducirMovimiento.matches ? 'instant' : 'smooth' });
        atencionFormulario?.cancel();
        const color = getComputedStyle(formulario).borderColor;
        const acento = getComputedStyle(formulario).getPropertyValue('--primario').trim();
        atencionFormulario = animar(formulario, [
            { borderColor: color },
            { borderColor: acento, offset: .3 },
            { borderColor: color },
        ], 600);
    });
});

// Ninguna animación continúa en segundo plano ni ignora un cambio de preferencia.
function detenerMovimiento() {
    resortes.forEach((restablecer) => restablecer());
    animaciones.forEach((animacion) => animacion.finish());
}
reducirMovimiento.addEventListener('change', () => {
    if (reducirMovimiento.matches) detenerMovimiento();
});
document.addEventListener('visibilitychange', () => {
    if (document.hidden) detenerMovimiento();
});
window.addEventListener('blur', () => resortes.forEach((restablecer) => restablecer()));
