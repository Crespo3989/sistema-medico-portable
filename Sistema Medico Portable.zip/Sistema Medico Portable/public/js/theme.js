// Se ejecuta antes del CSS para restaurar la apariencia sin un destello claro.
(() => {
    const clave = 'sistema-medico-apariencia';
    const sistema = matchMedia('(prefers-color-scheme: dark)');
    const opciones = ['sistema', 'claro', 'oscuro'];
    let preferencia = 'sistema';
    try {
        const guardada = localStorage.getItem(clave);
        if (opciones.includes(guardada)) preferencia = guardada;
    } catch { /* La apariencia sigue funcionando sin almacenamiento disponible. */ }

    const aplicar = () => {
        const oscuro = preferencia === 'oscuro' || (preferencia === 'sistema' && sistema.matches);
        document.documentElement.dataset.theme = oscuro ? 'clinica-noche' : 'clinica';
        document.querySelectorAll('[data-apariencia]').forEach(control => {
            control.value = preferencia;
        });
    };
    aplicar();
    sistema.addEventListener('change', aplicar);
    addEventListener('storage', evento => {
        if (evento.key !== clave) return;
        preferencia = opciones.includes(evento.newValue) ? evento.newValue : 'sistema';
        aplicar();
    });
    document.addEventListener('DOMContentLoaded', () => {
        aplicar();
        document.querySelectorAll('[data-apariencia]').forEach(control => {
            control.addEventListener('change', () => {
                if (!opciones.includes(control.value)) return;
                preferencia = control.value;
                try { localStorage.setItem(clave, preferencia); } catch {}
                aplicar();
            });
        });
    });
})();
