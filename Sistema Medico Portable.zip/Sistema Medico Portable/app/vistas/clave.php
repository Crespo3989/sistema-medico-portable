<section class="card card-border tarjeta tarjeta-estrecha">
    <div class="tarjeta-titulo">
        <span class="chip-icono chip-azul"><?= icono('llave') ?></span>
        <div>
            <h1>Cambiar contraseña</h1>
            <p class="subtitulo">Usa al menos 8 caracteres. Evita datos fáciles de adivinar.</p>
        </div>
    </div>
    <form method="post" action="index.php" class="formulario">
        <?= campo_csrf() ?>
        <div class="campo">
            <label for="actual">Contraseña actual</label>
            <input class="input" type="password" id="actual" name="actual" autocomplete="current-password" required autofocus>
        </div>
        <div class="campo">
            <label for="nueva">Nueva contraseña</label>
            <input class="input" type="password" id="nueva" name="nueva" autocomplete="new-password" minlength="8" required>
        </div>
        <div class="campo">
            <label for="confirmar">Repite la nueva contraseña</label>
            <input class="input" type="password" id="confirmar" name="confirmar" autocomplete="new-password" minlength="8" required>
        </div>
        <div class="acciones">
            <a href="index.php" class="btn boton boton-secundario btn-ghost">Volver</a>
            <button type="submit" name="accion" value="clave" class="btn boton btn-primary">Guardar contraseña</button>
        </div>
    </form>
</section>
