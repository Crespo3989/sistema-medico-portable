<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <title><?= e($titulo) ?> · <?= e($config['nombre_sistema']) ?></title>
    <script src="js/theme.js?v=<?= filemtime(__DIR__ . '/../../public/js/theme.js') ?>"></script>
    <link rel="stylesheet" href="css/app.css?v=<?= filemtime(__DIR__ . '/../../public/css/app.css') ?>">
    <script src="js/app.js?v=sesion-1" defer></script>
</head>
<body class="vista-<?= e($vista) ?>">
<?php if ($vista === 'login'): ?>
    <?php require __DIR__ . '/login.php'; ?>
<?php else: ?>
    <?php if ($usuario !== null): ?>
        <a class="saltar-contenido" href="#contenido">Saltar al contenido</a>
        <aside class="lateral" aria-label="Navegación principal">
            <a href="index.php" class="marca"><span class="logo" aria-hidden="true"></span><span><?= e($config['nombre_sistema']) ?><small>Gestión de citas</small></span></a>
            <nav aria-label="Secciones">
                <ul class="menu navegacion">
                    <li><a href="index.php" <?= $vista === 'panel' ? 'aria-current="page"' : '' ?>><?= icono('calendario') ?>Agenda de citas</a></li>
                    <li><a href="index.php?vista=clave" <?= $vista === 'clave' ? 'aria-current="page"' : '' ?>><?= icono('escudo') ?>Seguridad</a></li>
                </ul>
            </nav>
            <div class="lateral-pie">
                <?= icono('disco') ?>
                <div><strong>Almacenamiento local</strong><p>Los datos permanecen en este equipo.</p></div>
            </div>
        </aside>
        <header class="barra">
            <div class="barra-interior">
                <a href="index.php" class="marca marca-movil" aria-label="<?= e($config['nombre_sistema']) ?>, agenda"><span class="logo" aria-hidden="true"></span><span class="marca-nombre"><?= e($config['nombre_sistema']) ?></span></a>
                <span class="ubicacion"><?= icono($vista === 'clave' ? 'escudo' : 'calendario') ?><strong><?= $vista === 'clave' ? 'Seguridad' : ($vista === 'eliminar' ? 'Eliminar cita' : 'Agenda de citas') ?></strong></span>
                <?php if ($vista === 'panel'): ?>
                    <div class="acciones-barra" role="group" aria-label="Acciones de la agenda">
                        <button type="button" id="imprimir" class="btn boton boton-herramienta" aria-label="Imprimir listado" title="Imprimir listado"><?= icono('imprimir') ?><span class="texto-herramienta">Imprimir</span></button>
                        <a class="btn boton boton-nueva" href="#nueva-cita" aria-label="Nueva cita" title="Nueva cita"><?= icono('mas') ?><span class="texto-herramienta">Nueva cita</span></a>
                    </div>
                <?php endif; ?>
                <?php require __DIR__ . '/apariencia.php'; ?>
                <details class="menu-usuario">
                    <summary aria-label="Menú de usuario">
                        <span class="avatar avatar-pequeno"><?= e(iniciales($usuario)) ?></span>
                        <span class="menu-nombre"><?= e($usuario) ?><small>Mi cuenta</small></span>
                    </summary>
                    <div class="menu-desplegable">
                        <a href="index.php?vista=clave"><?= icono('llave') ?>Cambiar contraseña</a>
                        <form method="post" action="index.php">
                            <?= campo_csrf() ?>
                            <button type="submit" name="accion" value="logout"><?= icono('salir') ?>Cerrar sesión</button>
                        </form>
                    </div>
                </details>
            </div>
        </header>
    <?php endif; ?>

    <main class="contenedor" id="contenido" tabindex="-1">
        <?php require __DIR__ . '/avisos.php'; ?>
        <?php require __DIR__ . '/' . $vista . '.php'; ?>
    </main>
    <?php if ($usuario !== null): ?>
        <footer class="pie-sistema"><span><?= e($config['nombre_sistema']) ?> · Gestión del consultorio</span><span><?= icono('candado') ?>Sesión protegida</span></footer>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>
