<?php
$iconos_aviso = ['exito' => 'atendida', 'error' => 'cancelada', 'alerta' => 'escudo', 'info' => 'reloj'];
foreach ($mensajes as [$tipo, $texto]): ?>
    <div class="aviso aviso-<?= e($tipo) ?>" role="<?= $tipo === 'error' ? 'alert' : 'status' ?>">
        <?= icono($iconos_aviso[$tipo] ?? 'reloj') ?><span><?= e($texto) ?></span>
    </div>
<?php endforeach; ?>
