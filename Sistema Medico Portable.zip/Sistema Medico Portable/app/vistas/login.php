<main class="acceso">
    <div class="apariencia-acceso"><?php require __DIR__ . '/apariencia.php'; ?></div>
    <section class="acceso-texto">
        <div class="marca marca-clara"><span class="logo" aria-hidden="true"></span><span><?= e($config['nombre_sistema']) ?><small>Gestión de citas</small></span></div>
        <div class="acceso-mensaje">
            <h1>Tu agenda médica,<br>clara y organizada.</h1>
            <p>Agenda, busca y da seguimiento a las citas de tus pacientes desde un solo lugar.</p>
            <ul class="ventajas">
                <li><?= icono('calendario') ?>Citas sin cruces de horario</li>
                <li><?= icono('disco') ?>Datos guardados en tu equipo, sin Internet</li>
                <li><?= icono('escudo') ?>Acceso protegido con contraseña</li>
            </ul>
        </div>
        <p class="acceso-pie"><?= icono('escudo') ?>Una agenda organizada, una atención más cercana.</p>
    </section>

    <section class="acceso-tarjeta" aria-labelledby="titulo-acceso">
        <span class="acceso-simbolo" aria-hidden="true"><?= icono('candado') ?></span>
        <h2 id="titulo-acceso">Bienvenido a tu consultorio</h2>
        <p class="subtitulo">Inicia sesión para gestionar tus citas.</p>

        <?php require __DIR__ . '/avisos.php'; ?>

        <form method="post" action="index.php" class="formulario">
            <?= campo_csrf() ?>
            <div class="campo">
                <label for="usuario">Usuario</label>
                <div class="con-icono">
                    <?= icono('usuario') ?>
                    <input class="input" type="text" id="usuario" name="usuario" value="<?= e($ultimo_usuario) ?>"
                           autocomplete="username" placeholder="Tu nombre de usuario" required autofocus>
                </div>
            </div>
            <div class="campo">
                <label for="clave">Contraseña</label>
                <div class="con-icono">
                    <?= icono('candado') ?>
                    <input class="input" type="password" id="clave" name="clave" autocomplete="current-password" placeholder="Ingresa tu contraseña" required>
                    <button type="button" class="mostrar-clave" data-clave="clave" aria-label="Mostrar contraseña" aria-pressed="false"><?= icono('ojo') ?></button>
                </div>
            </div>
            <button type="submit" name="accion" value="login" class="btn boton boton-grande btn-primary">
                Ingresar <?= icono('flecha') ?>
            </button>
        </form>

        <?php if ($mostrar_pista): ?>
            <p class="pista">
                <strong>Primer uso:</strong> usuario <code>admin</code> y contraseña <code><?= e(CLAVE_INICIAL) ?></code>.
                Al entrar se te pedirá cambiarla.
            </p>
        <?php endif; ?>
        <p class="acceso-nota"><?= icono('disco') ?>Acceso local · Funciona sin Internet</p>
    </section>
</main>
