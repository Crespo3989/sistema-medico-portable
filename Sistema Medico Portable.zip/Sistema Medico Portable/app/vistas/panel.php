<?php
$datos = $form['datos'];
$errores = $form['errores'];
$filtros_activos = array_filter($filtros);
$accion_estado = 'index.php' . ($filtros_activos ? '?' . http_build_query($filtros_activos) : '');
$botones_estado = [
    'Registrada' => [['Atendida', 'Marcar atendida', 'check', 'boton-exito btn-success'], ['Cancelada', 'Cancelar', 'x', 'boton-peligro btn-error']],
    'Atendida'   => [['Registrada', 'Reabrir', 'deshacer', 'boton-secundario btn-ghost']],
    'Cancelada'  => [['Registrada', 'Reactivar', 'deshacer', 'boton-secundario btn-ghost']],
];
$tarjetas = [
    ['hoy', 'Citas hoy', 'calendario', 'chip-azul'],
    ['proximas', 'Pendientes', 'reloj', 'chip-ambar'],
    ['atendidas', 'Atendidas', 'atendida', 'chip-verde'],
    ['canceladas', 'Canceladas', 'cancelada', 'chip-rojo'],
];
/** Atributos de accesibilidad para un campo con error. */
$attr_error = fn(string $campo) => isset($errores[$campo]) ? 'aria-invalid="true" aria-describedby="error-' . $campo . '"' : '';
$msg_error = fn(string $campo) => isset($errores[$campo])
    ? '<small id="error-' . $campo . '" class="error-campo">' . e($errores[$campo]) . '</small>' : '';
?>
<div class="encabezado-pagina">
    <div class="w-full md:grid md:grid-cols-[1fr_auto] md:items-center md:gap-x-6">
        <h1>Agenda de citas</h1>
        <p class="subtitulo"><?= e(saludo()) ?>, <?= e($usuario) ?>. Organiza la atención de tus pacientes.</p>
        <p class="fecha-hoy md:col-start-2 md:row-start-1 md:row-span-2 md:mt-0"><?= icono('calendario') ?><?= e(ucfirst(fecha_larga(new DateTimeImmutable($hoy)))) ?></p>
    </div>
</div>

<?php if (!empty($_SESSION['clave_inicial'])): ?>
    <div class="aviso aviso-alerta" role="alert">
        <?= icono('escudo') ?>
        <span>Estás usando la contraseña inicial. <a href="index.php?vista=clave">Cámbiala ahora</a> para proteger los datos de los pacientes.</span>
    </div>
<?php endif; ?>

<section class="resumen" aria-label="Resumen de citas">
    <?php foreach ($tarjetas as [$clave, $texto, $ico, $color]): ?>
        <div class="dato">
            <span class="chip-icono <?= $color ?>"><?= icono($ico) ?></span>
            <div>
                <span class="cifra"><?= (int) $resumen[$clave] ?></span>
                <span class="dato-texto"><?= e($texto) ?></span>
            </div>
        </div>
    <?php endforeach; ?>
</section>

<div class="columnas">
    <section class="card card-border tarjeta tarjeta-lista" aria-labelledby="titulo-citas">
        <div class="tarjeta-titulo tarjeta-titulo-lista">
            <div><h2 id="titulo-citas">Listado de citas</h2><p class="subtitulo">Consulta y actualiza cada atención.</p></div>
            <span class="badge contador"><?= count($citas) ?> <?= count($citas) === 1 ? 'resultado' : 'resultados' ?></span>
        </div>

        <form method="get" action="index.php" class="filtros solo-pantalla" role="search">
            <div class="campo filtro-busqueda">
                <label for="f-q">Buscar paciente</label>
                <div class="con-icono">
                    <?= icono('buscar') ?>
                    <input class="input" type="search" id="f-q" name="q" value="<?= e($filtros['q']) ?>" placeholder="Buscar paciente…">
                </div>
            </div>
            <div class="campo">
                <label for="f-esp">Especialidad</label>
                <select class="select" id="f-esp" name="especialidad">
                    <option value="">Todas las especialidades</option>
                    <?php foreach ($config['especialidades'] as $esp): ?>
                        <option <?= $filtros['especialidad'] === $esp ? 'selected' : '' ?>><?= e($esp) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="f-estado">Estado</label>
                <select class="select" id="f-estado" name="estado">
                    <option value="">Todos los estados</option>
                    <?php foreach (ESTADOS as $est): ?>
                        <option <?= $filtros['estado'] === $est ? 'selected' : '' ?>><?= e($est) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="f-fecha">Fecha</label>
                <input class="input" type="date" id="f-fecha" name="fecha" value="<?= e($filtros['fecha']) ?>">
            </div>
            <div class="filtros-botones">
                <button type="submit" class="btn boton boton-secundario btn-ghost"><?= icono('filtro') ?>Filtrar</button>
                <?php if ($filtros_activos): ?><a href="index.php" class="enlace-suave">Quitar filtros</a><?php endif; ?>
            </div>
        </form>

        <?php if (!$citas): ?>
            <div class="vacio">
                <?= icono('vacio', 'icono icono-vacio') ?>
                <h3><?= $filtros_activos ? 'Sin resultados para esta búsqueda' : 'Tu agenda comienza aquí' ?></h3>
                <p><?= $filtros_activos ? 'Prueba con otro paciente, fecha o especialidad.' : 'Registra tu primera cita y encuentra aquí toda la información de la atención.' ?></p>
                <a class="btn boton boton-secundario btn-ghost" href="<?= $filtros_activos ? 'index.php' : '#nueva-cita' ?>"><?= icono($filtros_activos ? 'deshacer' : 'mas') ?><?= $filtros_activos ? 'Quitar filtros' : 'Agendar primera cita' ?></a>
            </div>
        <?php else: ?>
            <div class="tabla-desplazable">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Fecha</th>
                            <th scope="col">Paciente</th>
                            <th scope="col">Hora</th>
                            <th scope="col">Estado</th>
                            <th scope="col" class="solo-pantalla"><span class="oculto">Acciones</span></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($citas as $cita):
                        $f = fecha_corta((string) $cita['fecha']);
                        $es_hoy = $cita['fecha'] === $hoy;
                        $pasada = $cita['fecha'] < $hoy; ?>
                        <tr class="<?= $es_hoy ? 'fila-hoy' : ($pasada ? 'fila-pasada' : '') ?>">
                            <td data-label="Fecha">
                                <?php if ($f): ?>
                                    <span class="etiqueta-fecha<?= $es_hoy ? ' etiqueta-fecha-hoy' : '' ?>" title="<?= e($cita['fecha']) ?>">
                                        <span class="ef-mes"><?= e($f['mes']) ?></span>
                                        <span class="ef-dia"><?= e($f['dia']) ?></span>
                                        <span class="ef-semana"><?= $es_hoy ? 'hoy' : e($f['semana']) ?></span>
                                    </span>
                                <?php else: ?>
                                    <?= e($cita['fecha']) ?>
                                <?php endif; ?>
                            </td>
                            <td data-label="Paciente">
                                <div class="paciente">
                                    <span class="avatar"><?= e(iniciales((string) $cita['paciente_nombre'])) ?></span>
                                    <div>
                                        <span class="paciente-nombre"><?= e($cita['paciente_nombre']) ?></span>
                                        <span class="paciente-detalle"><?= e($cita['especialidad']) ?><?= $f && $f['anio'] !== substr($hoy, 0, 4) ? ' · ' . e($f['anio']) : '' ?></span>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Hora"><span class="hora"><?= icono('reloj') ?><?= e($cita['hora']) ?></span></td>
                            <td data-label="Estado"><span class="badge estado estado-<?= e(strtolower((string) $cita['estado'])) ?>"><?= e($cita['estado']) ?></span></td>
                            <td class="solo-pantalla celda-acciones">
                                <form method="post" action="<?= e($accion_estado) ?>" class="acciones-fila">
                                    <?= campo_csrf() ?>
                                    <input type="hidden" name="accion" value="estado">
                                    <input type="hidden" name="id" value="<?= (int) $cita['id'] ?>">
                                    <?php foreach ($botones_estado[$cita['estado']] ?? [] as [$destino, $texto, $ico, $clase]): ?>
                                        <button type="submit" name="estado" value="<?= e($destino) ?>" class="btn boton boton-mini <?= $clase ?>"><?= icono($ico) ?><?= e($texto) ?></button>
                                    <?php endforeach; ?>
                                </form>
                                <form method="post" action="<?= e($accion_estado) ?>" class="acciones-fila">
                                    <?= campo_csrf() ?>
                                    <input type="hidden" name="id" value="<?= (int) $cita['id'] ?>">
                                    <button type="submit" name="accion" value="confirmar_eliminacion" class="btn boton boton-mini boton-peligro btn-error"
                                            aria-label="Eliminar cita de <?= e($cita['paciente_nombre']) ?> del <?= e($cita['fecha']) ?> a las <?= e($cita['hora']) ?>">
                                        <?= icono('papelera') ?>Eliminar
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="card card-border tarjeta tarjeta-formulario" id="nueva-cita" aria-labelledby="titulo-nueva">
        <div class="tarjeta-titulo">
            <span class="chip-icono chip-azul"><?= icono('mas') ?></span>
            <div><h2 id="titulo-nueva">Nueva cita</h2><p class="subtitulo">Reserva un espacio de atención.</p></div>
        </div>
        <form method="post" action="index.php" class="formulario">
            <?= campo_csrf() ?>
            <div class="campo">
                <label for="paciente">Nombre completo del paciente</label>
                <input class="input" type="text" id="paciente" name="paciente" maxlength="100" required placeholder="Ej.: María Pérez López"
                       value="<?= e($datos['paciente'] ?? '') ?>" <?= $attr_error('paciente') ?>>
                <?= $msg_error('paciente') ?>
            </div>
            <div class="campo">
                <label for="especialidad">Especialidad</label>
                <select class="select" id="especialidad" name="especialidad" required <?= $attr_error('especialidad') ?>>
                    <?php foreach ($config['especialidades'] as $esp): ?>
                        <option <?= ($datos['especialidad'] ?? '') === $esp ? 'selected' : '' ?>><?= e($esp) ?></option>
                    <?php endforeach; ?>
                </select>
                <?= $msg_error('especialidad') ?>
            </div>
            <div class="fila-campos">
                <div class="campo">
                    <label for="fecha">Fecha</label>
                    <input class="input" type="date" id="fecha" name="fecha" min="<?= e($hoy) ?>" required
                           value="<?= e($datos['fecha'] ?? '') ?>" <?= $attr_error('fecha') ?>>
                    <?= $msg_error('fecha') ?>
                </div>
                <div class="campo">
                    <label for="hora">Hora</label>
                    <input class="input" type="time" id="hora" name="hora" required
                           value="<?= e($datos['hora'] ?? '') ?>" <?= $attr_error('hora') ?>>
                    <?= $msg_error('hora') ?>
                </div>
            </div>
            <button type="submit" name="accion" value="agendar" class="btn boton boton-grande btn-primary"><?= icono('check') ?>Guardar cita</button>
        </form>
        <p class="nota-formulario"><?= icono('escudo') ?>El sistema comprueba la disponibilidad del horario antes de guardar.</p>
    </section>

</div>
