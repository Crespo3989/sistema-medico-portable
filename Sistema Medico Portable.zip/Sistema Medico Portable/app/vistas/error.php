<section class="card card-border tarjeta tarjeta-estrecha">
    <div class="tarjeta-titulo">
        <span class="chip-icono chip-rojo"><?= icono('disco') ?></span>
        <div>
            <h1>No se pudo iniciar el sistema</h1>
            <p class="subtitulo">Comprueba que la carpeta <code>data</code> exista y que la memoria USB no esté protegida contra escritura.
                Si el error menciona el driver de SQLite, revisa la <em>Guía de configuraciones</em>.</p>
        </div>
    </div>
</section>
