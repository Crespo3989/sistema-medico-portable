<section class="card card-border tarjeta tarjeta-estrecha" aria-labelledby="titulo-eliminar">
    <div class="tarjeta-titulo">
        <span class="chip-icono chip-rojo"><?= icono('papelera') ?></span>
        <div>
            <h1 id="titulo-eliminar">¿Eliminar esta cita?</h1>
            <p class="subtitulo">Revisa los datos antes de confirmar.</p>
        </div>
    </div>
    <dl class="detalle-cita">
        <div><dt>Paciente</dt><dd><?= e($cita_eliminar['paciente_nombre']) ?></dd></div>
        <div><dt>Especialidad</dt><dd><?= e($cita_eliminar['especialidad']) ?></dd></div>
        <div><dt>Fecha</dt><dd><?= e($cita_eliminar['fecha']) ?></dd></div>
        <div><dt>Hora</dt><dd><?= e($cita_eliminar['hora']) ?></dd></div>
        <div><dt>Estado</dt><dd><?= e($cita_eliminar['estado']) ?></dd></div>
    </dl>
    <div class="aviso aviso-alerta" role="note">
        <?= icono('escudo') ?><span>La cita se borrará definitivamente. Esta acción no se puede deshacer.</span>
    </div>
    <form method="post" action="<?= e($volver) ?>">
        <?= campo_csrf() ?>
        <input type="hidden" name="id" value="<?= (int) $cita_eliminar['id'] ?>">
        <input type="hidden" name="confirmar" value="1">
        <div class="acciones">
            <a href="<?= e($volver) ?>" class="btn boton boton-secundario btn-ghost" autofocus>Conservar cita</a>
            <button type="submit" name="accion" value="eliminar" class="btn boton boton-destructivo btn-error"><?= icono('papelera') ?>Sí, eliminar cita</button>
        </div>
    </form>
</section>
