<?php
// Configuración general del sistema. Ajusta estos valores según el consultorio.
return [
    'nombre_sistema'      => 'Sistema Médico',
    'zona_horaria'        => 'America/Guayaquil',
    'ruta_db'             => dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'citas_medicas.db',
    'especialidades'      => ['Medicina General', 'Pediatría', 'Odontología'],
    // Tiempo sin actividad tras el cual se cierra la sesión.
    'minutos_inactividad' => 30,
];
