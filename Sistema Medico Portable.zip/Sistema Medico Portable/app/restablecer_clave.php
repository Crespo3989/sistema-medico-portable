<?php
// Restablece la contraseña de "admin" a la inicial. Solo se ejecuta desde la consola (RESTABLECER_CLAVE.bat).
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
$config = require __DIR__ . '/config.php';
require __DIR__ . '/db.php';

$pdo = conectar($config['ruta_db']);
$stmt = $pdo->prepare("UPDATE usuarios SET password = ? WHERE usuario = 'admin'");
$stmt->execute([password_hash(CLAVE_INICIAL, PASSWORD_DEFAULT)]);
if (!$stmt->rowCount()) {
    $pdo->prepare("INSERT INTO usuarios (usuario, password) VALUES ('admin', ?)")
        ->execute([password_hash(CLAVE_INICIAL, PASSWORD_DEFAULT)]);
}
echo "Listo. Usuario: admin  Contrasena: " . CLAVE_INICIAL . PHP_EOL;
echo "Cambiala en cuanto vuelvas a entrar." . PHP_EOL;
