<?php
// Formatos de fecha en español e íconos SVG (no depende de la extensión intl ni de Internet).

const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto',
               'septiembre', 'octubre', 'noviembre', 'diciembre'];

/** "viernes, 25 de septiembre de 2026" */
function fecha_larga(DateTimeInterface $f): string
{
    return DIAS[(int) $f->format('w')] . ', ' . $f->format('j') . ' de ' . MESES[(int) $f->format('n') - 1] . ' de ' . $f->format('Y');
}

/** Partes para la etiqueta de fecha de la tabla: ['dia' => '26', 'mes' => 'sep', 'semana' => 'vie']. */
function fecha_corta(string $ymd): ?array
{
    $f = DateTimeImmutable::createFromFormat('!Y-m-d', $ymd);
    if (!$f) {
        return null;
    }
    return [
        'dia'    => $f->format('j'),
        'mes'    => iconv_substr(MESES[(int) $f->format('n') - 1], 0, 3, 'UTF-8'),
        'semana' => iconv_substr(DIAS[(int) $f->format('w')], 0, 3, 'UTF-8'),
        'anio'   => $f->format('Y'),
    ];
}

function saludo(): string
{
    $hora = (int) date('G');
    return $hora < 12 ? 'Buenos días' : ($hora < 19 ? 'Buenas tardes' : 'Buenas noches');
}

/** Iniciales para el avatar: primera letra del primer y del último nombre. */
function iniciales(string $nombre): string
{
    preg_match_all('/(?<!\p{L})\p{L}/u', $nombre, $m);
    $letras = $m[0];
    return match (count($letras)) {
        0 => '?',
        1 => $letras[0],
        default => $letras[0] . end($letras),
    };
}

/** Íconos de trazo (estilo lineal) dibujados en SVG. */
function icono(string $nombre, string $clase = 'icono'): string
{
    static $trazos = [
        'papelera'   => '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
        'ojo'        => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'calendario' => '<rect x="3" y="4.5" width="18" height="17" rx="2.5"/><path d="M16 2.5v4M8 2.5v4M3 10h18"/>',
        'reloj'      => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'atendida'   => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.5 2.5 4.5-5"/>',
        'cancelada'  => '<circle cx="12" cy="12" r="9"/><path d="m15 9-6 6M9 9l6 6"/>',
        'check'      => '<path d="M20 6 9 17l-5-5"/>',
        'x'          => '<path d="M18 6 6 18M6 6l12 12"/>',
        'deshacer'   => '<path d="M3 7v6h6"/><path d="M21 17a9 9 0 0 0-15-6.7L3 13"/>',
        'buscar'     => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
        'usuario'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
        'candado'    => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        'llave'      => '<circle cx="8" cy="15" r="4"/><path d="m10.8 12.2 8.7-8.7M16 7l3 3M13.5 9.5l2 2"/>',
        'salir'      => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
        'mas'        => '<path d="M12 5v14M5 12h14"/>',
        'flecha'     => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'imprimir'   => '<path d="M6 9V3h12v6"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="7" rx="1"/>',
        'escudo'     => '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
        'disco'      => '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
        'filtro'     => '<path d="M3 5h18l-7 8.5V20l-4-2v-4.5z"/>',
        'vacio'      => '<rect x="3" y="4.5" width="18" height="17" rx="2.5"/><path d="M16 2.5v4M8 2.5v4M3 10h18M9.5 14.5l5 4M14.5 14.5l-5 4"/>',
    ];
    return '<svg class="' . $clase . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" '
        . 'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . ($trazos[$nombre] ?? '') . '</svg>';
}
