<?php
// Reglas de las citas: validación, consultas y cambios de estado.

const ESTADOS = ['Registrada', 'Atendida', 'Cancelada'];

/** Devuelve [datos normalizados, errores por campo]. */
function validar_cita(array $entrada, array $especialidades): array
{
    $datos = [
        'paciente'     => trim((string) preg_replace('/\s+/u', ' ', (string) ($entrada['paciente'] ?? ''))),
        'especialidad' => (string) ($entrada['especialidad'] ?? ''),
        'fecha'        => (string) ($entrada['fecha'] ?? ''),
        'hora'         => substr((string) ($entrada['hora'] ?? ''), 0, 5), // algunos navegadores envían segundos
    ];
    $errores = [];

    if (!preg_match("/^\p{L}[\p{L}\s'.-]{2,99}$/u", $datos['paciente'])) {
        $errores['paciente'] = 'Escribe el nombre completo: solo letras, entre 3 y 100 caracteres.';
    }
    if (!in_array($datos['especialidad'], $especialidades, true)) {
        $errores['especialidad'] = 'Elige una especialidad de la lista.';
    }
    $fecha = DateTimeImmutable::createFromFormat('!Y-m-d', $datos['fecha']);
    if (!$fecha || $fecha->format('Y-m-d') !== $datos['fecha']) {
        $errores['fecha'] = 'Fecha no válida.';
    }
    $hora = DateTimeImmutable::createFromFormat('!H:i', $datos['hora']);
    if (!$hora || $hora->format('H:i') !== $datos['hora']) {
        $errores['hora'] = 'Hora no válida.';
    }
    if (!isset($errores['fecha']) && !isset($errores['hora'])
        && new DateTimeImmutable($datos['fecha'] . ' ' . $datos['hora']) < new DateTimeImmutable()) {
        $errores['fecha'] = 'La fecha y hora ya pasaron.';
    }
    return [$datos, $errores];
}

/** Una especialidad no puede tener dos citas activas (no canceladas) a la misma hora. */
function horario_ocupado(PDO $pdo, string $especialidad, string $fecha, string $hora, ?int $excluir_id = null): bool
{
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM citas
        WHERE especialidad = ? AND fecha = ? AND hora = ? AND estado <> 'Cancelada' AND id <> ?");
    $stmt->execute([$especialidad, $fecha, $hora, $excluir_id ?? 0]);
    return (bool) $stmt->fetchColumn();
}

function crear_cita(PDO $pdo, array $datos): void
{
    $pdo->prepare('INSERT INTO citas (paciente_nombre, especialidad, fecha, hora) VALUES (?, ?, ?, ?)')
        ->execute([$datos['paciente'], $datos['especialidad'], $datos['fecha'], $datos['hora']]);
}

/** Devuelve null si el cambio se hizo, o el motivo por el que no se pudo. */
function cambiar_estado(PDO $pdo, int $id, string $estado): ?string
{
    if (!in_array($estado, ESTADOS, true)) {
        return 'Estado no válido.';
    }
    $stmt = $pdo->prepare('SELECT * FROM citas WHERE id = ?');
    $stmt->execute([$id]);
    $cita = $stmt->fetch();
    if (!$cita) {
        return 'La cita no existe.';
    }
    if ($cita['estado'] === 'Cancelada' && $estado !== 'Cancelada'
        && horario_ocupado($pdo, $cita['especialidad'], $cita['fecha'], $cita['hora'], $id)) {
        return 'No se puede reactivar: ese horario ya está ocupado por otra cita.';
    }
    $pdo->prepare('UPDATE citas SET estado = ? WHERE id = ?')->execute([$estado, $id]);
    return null;
}

/** Toma los filtros de la URL y descarta los valores no válidos. */
function leer_filtros(array $get, array $especialidades): array
{
    $fecha = (string) ($get['fecha'] ?? '');
    return [
        'q'            => trim((string) iconv_substr((string) ($get['q'] ?? ''), 0, 100, 'UTF-8')),
        'especialidad' => in_array($get['especialidad'] ?? '', $especialidades, true) ? $get['especialidad'] : '',
        'estado'       => in_array($get['estado'] ?? '', ESTADOS, true) ? $get['estado'] : '',
        'fecha'        => preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha) ? $fecha : '',
    ];
}

/** Elimina únicamente la cita indicada; devuelve un error si ya no existe. */
function eliminar_cita(PDO $pdo, int $id): ?string
{
    if ($id < 1) {
        return 'La cita no existe o ya fue eliminada.';
    }
    $stmt = $pdo->prepare('DELETE FROM citas WHERE id = ?');
    $stmt->execute([$id]);
    return $stmt->rowCount() === 1 ? null : 'La cita no existe o ya fue eliminada.';
}

function listar_citas(PDO $pdo, array $filtros): array
{
    $condiciones = [];
    $valores = [];
    if ($filtros['q'] !== '') {
        $condiciones[] = "paciente_nombre LIKE ? ESCAPE '\\'";
        $valores[] = '%' . addcslashes($filtros['q'], '%_\\') . '%';
    }
    foreach (['especialidad', 'estado', 'fecha'] as $campo) {
        if ($filtros[$campo] !== '') {
            $condiciones[] = "$campo = ?";
            $valores[] = $filtros[$campo];
        }
    }
    $sql = 'SELECT * FROM citas'
        . ($condiciones ? ' WHERE ' . implode(' AND ', $condiciones) : '')
        . ' ORDER BY fecha DESC, hora DESC, id DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($valores);
    return $stmt->fetchAll();
}

function resumen_citas(PDO $pdo, string $hoy): array
{
    $stmt = $pdo->prepare("SELECT
        COALESCE(SUM(fecha = :hoy AND estado <> 'Cancelada'), 0) AS hoy,
        COALESCE(SUM(fecha >= :hoy AND estado = 'Registrada'), 0) AS proximas,
        COALESCE(SUM(estado = 'Atendida'), 0) AS atendidas,
        COALESCE(SUM(estado = 'Cancelada'), 0) AS canceladas
        FROM citas");
    $stmt->execute(['hoy' => $hoy]);
    return $stmt->fetch();
}
