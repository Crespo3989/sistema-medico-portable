<?php
// Sesión, protección CSRF, escape de HTML y mensajes entre peticiones.

function e(mixed $texto): string
{
    return htmlspecialchars((string) $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function enviar_cabeceras_seguridad(): void
{
    header("Content-Security-Policy: default-src 'self'; style-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    // Las páginas contienen datos de pacientes: que el navegador no las guarde en caché.
    header('Cache-Control: no-store');
}

function iniciar_sesion(int $minutos_inactividad): void
{
    // Las cookies no distinguen puertos: cada instalación y servidor necesita su nombre.
    $ambito = __DIR__ . '|' . (string) ($_SERVER['SERVER_PORT'] ?? 'cli');
    session_name('SMEDICO' . substr(hash('sha256', $ambito), 0, 12));
    $carpeta = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'sesiones';
    if (!is_dir($carpeta) && !mkdir($carpeta, 0700, true) && !is_dir($carpeta)) {
        throw new RuntimeException('No se pudo crear la carpeta de sesiones del sistema.');
    }
    session_save_path($carpeta);
    // Evita que PHP elimine la sesión antes del tiempo de inactividad configurado.
    ini_set('session.gc_maxlifetime', (string) max((int) ini_get('session.gc_maxlifetime'), $minutos_inactividad * 60));
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params(['path' => '/', 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    $ahora = time();
    if (isset($_SESSION['usuario_id'], $_SESSION['ultimo_acceso'])
        && $ahora - $_SESSION['ultimo_acceso'] > $minutos_inactividad * 60) {
        cerrar_sesion();
        flash('info', 'Tu sesión se cerró por inactividad. Vuelve a ingresar.');
    }
    $_SESSION['ultimo_acceso'] = $ahora;
}

function cerrar_sesion(): void
{
    $_SESSION = [];
    session_regenerate_id(true);
}

function token_csrf(): string
{
    return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
}

function campo_csrf(): string
{
    return '<input type="hidden" name="csrf" value="' . e(token_csrf()) . '">';
}

function verificar_csrf(): bool
{
    $token = $_POST['csrf'] ?? null;
    $esperado = $_SESSION['csrf'] ?? null;
    return is_string($token) && is_string($esperado) && hash_equals($esperado, $token);
}

/** Guarda un mensaje para mostrarlo después de redirigir. Tipos: exito, error, info, alerta. */
function flash(string $tipo, string $texto): void
{
    $_SESSION['flash'][] = [$tipo, $texto];
}

function tomar_flash(): array
{
    $mensajes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $mensajes;
}

function redirigir(string $destino = 'index.php'): never
{
    header('Location: ' . $destino);
    exit;
}
