<?php
// Conexión a SQLite y migraciones del esquema.

const CLAVE_INICIAL = '1234';

function conectar(string $ruta): PDO
{
    $carpeta = dirname($ruta);
    if (!is_dir($carpeta) && !mkdir($carpeta, 0775, true)) {
        throw new PDOException("No se pudo crear la carpeta $carpeta");
    }
    $pdo = new PDO('sqlite:' . $ruta, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA busy_timeout = 5000');
    migrar($pdo);
    return $pdo;
}

/** Cada migración se aplica una sola vez; PRAGMA user_version guarda la última aplicada. */
function migrar(PDO $pdo): void
{
    $version = (int) $pdo->query('PRAGMA user_version')->fetchColumn();

    if ($version < 1) {
        $pdo->beginTransaction();
        $pdo->exec("CREATE TABLE IF NOT EXISTS usuarios (
            id       INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario  TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS citas (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            paciente_nombre TEXT NOT NULL,
            especialidad    TEXT NOT NULL,
            fecha           TEXT NOT NULL,
            hora            TEXT NOT NULL,
            estado          TEXT NOT NULL DEFAULT 'Registrada'
        )");
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_citas_fecha ON citas (fecha, hora)');

        // La versión anterior guardaba las contraseñas en texto plano: se convierten a hash.
        $actualizar = $pdo->prepare('UPDATE usuarios SET password = ? WHERE id = ?');
        foreach ($pdo->query('SELECT id, password FROM usuarios')->fetchAll() as $u) {
            if (password_get_info($u['password'])['algo'] === null) {
                $actualizar->execute([password_hash($u['password'], PASSWORD_DEFAULT), $u['id']]);
            }
        }
        if (!$pdo->query('SELECT COUNT(*) FROM usuarios')->fetchColumn()) {
            $pdo->prepare('INSERT INTO usuarios (usuario, password) VALUES (?, ?)')
                ->execute(['admin', password_hash(CLAVE_INICIAL, PASSWORD_DEFAULT)]);
        }
        $pdo->exec('PRAGMA user_version = 1');
        $pdo->commit();
    }
}

/** Indica si el usuario admin sigue con la contraseña inicial (para mostrar la pista de primer uso). */
function clave_inicial_activa(PDO $pdo): bool
{
    $hash = $pdo->query("SELECT password FROM usuarios WHERE usuario = 'admin'")->fetchColumn();
    return is_string($hash) && password_verify(CLAVE_INICIAL, $hash);
}
