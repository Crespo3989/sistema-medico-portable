@echo off
setlocal
title Sistema Medico Portable - Alex Avila

:: Todas las rutas son relativas a esta carpeta, asi funciona desde cualquier unidad o memoria USB.
cd /d "%~dp0"
set "PHP_BIN=%~dp0php\php.exe"
set "PHP_INI=%~dp0php\php.ini"
set "PHP_EXT=%~dp0php\ext"
set "DOCROOT=%~dp0public"
set "LOG=%~dp0data\servidor.log"
set "PUERTO=8080"
set "URL=http://127.0.0.1:%PUERTO%"

echo ---------------------------------------------------
echo   SISTEMA MEDICO PORTABLE
echo ---------------------------------------------------

if not exist "%PHP_BIN%" (
    echo [ERROR] No se encontro PHP en:
    echo         %PHP_BIN%
    echo Revisa "Guia de configuraciones\php descarga.txt".
    goto :fin
)

:: Comprueba que el driver de SQLite este activo antes de arrancar.
"%PHP_BIN%" -c "%PHP_INI%" -d extension_dir="%PHP_EXT%" -r "exit(extension_loaded('pdo_sqlite') ? 0 : 1);"
if errorlevel 1 (
    echo [ERROR] El driver pdo_sqlite no esta activo en php.ini.
    echo Revisa "Guia de configuraciones\Activar el Driver en el archivo php.ini.txt".
    goto :fin
)

netstat -an | findstr /r /c:":%PUERTO% .*LISTENING" >nul
if errorlevel 1 goto :iniciar

:: El puerto esta ocupado: si es este mismo sistema (abierto en otra ventana), solo se abre el navegador.
"%PHP_BIN%" -n -d default_socket_timeout=3 -r "exit(str_contains((string) @file_get_contents('%URL%/'), 'vista-') ? 0 : 1);"
if not errorlevel 1 (
    echo El sistema ya estaba abierto en otra ventana.
    echo Abriendo %URL% en el navegador...
    start "" %URL%
    timeout /t 4 >nul
    exit /b 0
)
echo [ERROR] Otro programa esta usando el puerto %PUERTO%.
echo Cierra ese programa o cambia el puerto en este archivo (linea: set "PUERTO=%PUERTO%").
goto :fin

:iniciar
echo Servidor: %URL%
echo.
echo  - NO CIERRES ESTA VENTANA mientras uses el sistema.
echo  - Para detenerlo, cierra esta ventana.
echo  - Si cerraste el navegador, vuelve a ejecutar este archivo
echo    o abre %URL%
echo ---------------------------------------------------

:: Abre el navegador con un pequeno retraso para dar tiempo a que arranque el servidor.
start "" /min cmd /c "timeout /t 2 /nobreak >nul & start %URL%"

:: Solo se publica la carpeta "public": la base de datos y el codigo de "app" no son accesibles desde el navegador.
:: El registro del servidor va a data\servidor.log y no a esta ventana: asi, si se hace clic en la ventana
:: (modo "Seleccionar" de Windows), el servidor no se congela.
"%PHP_BIN%" -c "%PHP_INI%" -d extension_dir="%PHP_EXT%" -S 127.0.0.1:%PUERTO% -t "%DOCROOT%" > "%LOG%" 2>&1

echo.
echo El servidor se detuvo. Ultimas lineas del registro (data\servidor.log):
"%PHP_BIN%" -n -r "echo implode('', array_slice((array) @file(getenv('LOG')), -5));"

:fin
echo.
pause
